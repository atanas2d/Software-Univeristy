<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Problem 1: Personal Info</title>
</head>
<body>
<h1>Personal info:</h1>
<?php
$firstName = "Atanas";
$lastName = "Dimitrov";
$age = "28";

echo "My name is " . $firstName . " " . $lastName . " and I am " . $age . " years old.";

?>
</body>
</html>

