<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Problem2: Sum Two Numbers</title>
</head>
<body>
<?php
$firstNUmber = 5;
$secondNumber = 3;
$result = $firstNUmber + $secondNumber;
echo '$firstNumber + $secondNumber = ' . $firstNUmber . ' + ' . $secondNumber . ' = ' . number_format($result, 2);

?>
</body>
</html>